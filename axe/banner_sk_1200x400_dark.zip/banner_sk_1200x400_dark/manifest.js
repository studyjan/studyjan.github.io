FT.manifest({
    "filename": "index.html",
    "width": 1200,
    "height": 400,
    "clickTagCount": 1
});
