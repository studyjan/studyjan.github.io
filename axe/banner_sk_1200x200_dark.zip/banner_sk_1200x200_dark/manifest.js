FT.manifest({
    "filename": "index.html",
    "width": 1200,
    "height": 200,
    "clickTagCount": 1
});
