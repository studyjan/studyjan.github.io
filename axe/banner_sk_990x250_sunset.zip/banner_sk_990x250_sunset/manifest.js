FT.manifest({
    "filename": "index.html",
    "width": 990,
    "height": 250,
    "clickTagCount": 1
});
