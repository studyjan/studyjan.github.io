FT.manifest({
    "filename": "index.html",
    "width": 480,
    "height": 300,
    "clickTagCount": 1
});
