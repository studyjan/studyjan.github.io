FT.manifest({
    "filename": "index.html",
    "width": 480,
    "height": 480,
    "clickTagCount": 1
});
