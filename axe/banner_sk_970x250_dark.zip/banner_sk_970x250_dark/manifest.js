FT.manifest({
    "filename": "index.html",
    "width": 970,
    "height": 250,
    "clickTagCount": 1
});
