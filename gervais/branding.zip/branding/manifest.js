FT.manifest({
    "filename": "index.html",
    "width": 2000,
    "height": 1400,
    "clickTagCount": 1
});